module.exports = {
    ...require('./productCondition'),
    ...require('./productAvailabilityStatus'),
}