module.exports = {
    createCustomerGroupController: require("./createCustomerGroupController"),
    updateCustomerGroupController: require("./updateCustomerGroupController"),
    getAllCustomerGroupsController: require("./getAllCustomerGroupsController"),
    getSingleCustomerGroupController: require("./getSingleCustomerGroupController"),
}