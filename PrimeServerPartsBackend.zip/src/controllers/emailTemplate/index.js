// 
module.exports = {
    addEmailTemplateOnListController: require('./addEmailTemplateOnListController'),
    updateEmailTemplateOnListController: require('./updateEmailTemplateOnListController'),
    getAllEmailTemplateListController: require('./getAllEmailTemplateListController'),
    getSingleEmailTemplateListController: require('./getSingleEmailTemplateListController'),
    addEmailTempHeaderFooterController: require('./addEmailTempHeaderFooterController'),
    updateEmailTempHeaderFooterController: require('./updateEmailTempHeaderFooterController'),
    getSingleEmailTempHeaderFooterController: require('./getSingleEmailTempHeaderFooterController'),
    getEmailTempHeaderFooterListController: require('./getEmailTempHeaderFooterListController'),
    createEmailTemplateController: require('./createEmailTemplateController'),
    updateEmailTemplateController: require('./updateEmailTemplateController'),
    getSingleEmailTemplateController: require('./getSingleEmailTemplateController'),
    getEmailTemplateListController: require('./getEmailTemplateListController'),
    getEmailTemplatePreviewController: require('./getEmailTemplatePreviewController'),
}