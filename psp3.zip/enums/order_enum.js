const order_activity_type = {
  CREATE_ORDER: "Create PO",
  ORDER_CREATE_ADMIN: "Order Created By Admin",
  ORDER_CREATE_CUSTOMER: "Order Created By Customer",
};

module.exports = {
  order_activity_type
}
