module.exports = {
    createAttrGroupController: require("./createAttrGroupController"),
    updateAttrGroupController: require("./updateAttrGroupController"),
    getAllAttrGroupController: require("./getAllAttrGroupController"),
    getSingleAttrGroupController: require("./getSingleAttrGroupController"),
}