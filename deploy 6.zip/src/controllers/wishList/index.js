// 
module.exports = {
    addWishListController: require("./addWishListController"),
    removeFromWishListController: require("./removeFromWishListController"),
    getWishListController: require("./getWishListController"),
}