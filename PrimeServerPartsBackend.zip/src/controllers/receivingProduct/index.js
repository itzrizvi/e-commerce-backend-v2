module.exports = {
    getSingleReceivingProductController: require('./getSingleReceivingProductController'),
    getReceivingProductListController: require('./getReceivingProductListController'),
    updateReceivingController: require('./updateReceivingController'),
    getReceivingHistoryController: require('./getReceivingHistoryController'),
}