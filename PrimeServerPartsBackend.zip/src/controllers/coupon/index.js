module.exports = {
    createCouponController: require("./createCouponController"),
    updateCouponController: require("./updateCouponController"),
    getSingleCouponController: require("./getSingleCouponController"),
    getSingleCouponByCodeController: require("./getSingleCouponByCodeController"),
    getAllCouponsController: require("./getAllCouponsController"),
}