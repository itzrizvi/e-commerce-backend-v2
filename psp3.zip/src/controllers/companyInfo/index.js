module.exports = {
    companyInfoController: require("./companyInfoController"),
    getCompanyInfoController: require("./getCompanyInfoController"),
    addCompanyBillingAddressController: require("./addCompanyBillingAddressController"),
    addCompanyShippingAddressController: require("./addCompanyShippingAddressController"),
    updateCompanyAddressController: require("./updateCompanyAddressController"),
}