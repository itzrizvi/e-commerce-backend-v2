module.exports = {
    getOrderListReportController: require('./getOrderListReportController'),
    getSingleOrderReportController: require('./getSingleOrderReportController'),
}