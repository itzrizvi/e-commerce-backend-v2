module.exports = {
    getAllRolesController: require("./getAllRolesController"),
    createRolesController: require("./createRolesController"),
    updateRoleController: require("./updateRoleController"),
    updateRolePermissionsController: require("./updateRolePermissionsController"),
    deleteRoleController: require("./deleteRoleController"),
    getSingleRoleController: require("./getSingleRoleController"),
}