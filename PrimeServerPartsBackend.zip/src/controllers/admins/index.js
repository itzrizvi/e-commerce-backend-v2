module.exports = {
    adminSignInController: require("./adminSignInController"),
    adminSignUpController: require("./adminSignUpController"),
    setPasswordController: require("./setPasswordController"),
    resetPasswordController: require("./resetPasswordController"),
}