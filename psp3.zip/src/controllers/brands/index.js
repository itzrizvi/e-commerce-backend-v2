module.exports = {
    createBrandController: require("./createBrandController"),
    getAllBrandsController: require("./getAllBrandsController"),
    getSingleBrandController: require("./getSingleBrandController"),
    updateBrandController: require("./updateBrandController"),
    getProductsByBrandController: require("./getProductsByBrandController"),
    allPublicBrandsController: require("./allPublicBrandsController"),
}