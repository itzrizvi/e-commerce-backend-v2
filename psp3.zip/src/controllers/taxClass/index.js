module.exports = {
    addTaxClassController: require('./addTaxClassController'),
    getSingleTaxClassAdminController: require('./getSingleTaxClassAdminController'),
    getSingleTaxClassPublicController: require('./getSingleTaxClassPublicController'),
    getTaxClassListController: require('./getTaxClassListController'),
    updateTaxClassController: require('./updateTaxClassController'),
}