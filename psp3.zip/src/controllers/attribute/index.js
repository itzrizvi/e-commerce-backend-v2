module.exports = {
    createAttributeController: require("./createAttributeController"),
    updateAttributeController: require("./updateAttributeController"),
    getAllAttributeController: require("./getAllAttributeController"),
    getSingleAttributeController: require("./getSingleAttributeController"),
}