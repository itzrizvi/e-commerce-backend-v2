module.exports = {
    poSettingController: require('./poSettingController'),
    createPurchaseOrderController: require('./createPurchaseOrderController'),
    updatePurchaseOrderController: require('./updatePurchaseOrderController'),
    getPurchaseOrderListController: require('./getPurchaseOrderListController'),
    getSinglePurchaseOrderController: require('./getSinglePurchaseOrderController'),
    updatePOStatusController: require('./updatePOStatusController'),
    createReceivingController: require('./createReceivingController'),
}