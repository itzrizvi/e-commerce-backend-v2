module.exports = {
    addProductConditionController: require('./addProductConditionController'),
    updateProductConditionController: require('./updateProductConditionController'),
    allProductConditionController: require('./allProductConditionController'),
    getSingleProductConditionController: require('./getSingleProductConditionController'),
}