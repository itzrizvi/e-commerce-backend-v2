// RESPONSE FORMATTER
module.exports = {
    groupResponse: (data) => {
        // console.log(data)
        return data
        // return {
        //     count: data ? data.length : 0,
        //     data: data
        // }
    },
    singleResponse: (data) => {
        return data;
    }
}