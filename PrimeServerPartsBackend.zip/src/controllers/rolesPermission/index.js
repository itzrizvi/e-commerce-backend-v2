module.exports = {
    createRolesPermissionController: require("./createRolesPermissionController"),
    getAllRolesPermissionController: require("./getAllRolesPermissionController"),
    getSingleRolesPermissionController: require('./getSingleRolesPermissionController'),
    updateRolesPermissionController: require('./updateRolesPermissionController'),
}