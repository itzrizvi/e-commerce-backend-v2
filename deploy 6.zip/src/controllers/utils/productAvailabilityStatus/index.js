module.exports = {
    addProductAvailabilityStatusController: require('./addProductAvailabilityStatusController'),
    updateProductAvailabilityStatusController: require('./updateProductAvailabilityStatusController'),
    allProductAvailabilityStatusController: require('./allProductAvailabilityStatusController'),
    getSingleProductAvailabilityStatusController: require('./getSingleProductAvailabilityStatusController'),
}