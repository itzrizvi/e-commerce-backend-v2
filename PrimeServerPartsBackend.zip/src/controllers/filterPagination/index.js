// 
module.exports = {
    getFilterPaginatedProductsController: require('./getFilterPaginatedProductsController'),
}