module.exports = {
    companyInfoController: require("./companyInfoController"),
    getCompanyInfoController: require("./getCompanyInfoController"),
}