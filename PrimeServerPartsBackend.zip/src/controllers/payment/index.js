module.exports = {
    addPaymentMethodController: require('./addPaymentMethodController'),
    getSinglePaymentMethodController: require('./getSinglePaymentMethodController'),
    updatePaymentMethodController: require('./updatePaymentMethodController'),
    getPaymentMethodListAdminController: require('./getPaymentMethodListAdminController'),
    getPaymentMethodListPublicController: require('./getPaymentMethodListPublicController'),
}