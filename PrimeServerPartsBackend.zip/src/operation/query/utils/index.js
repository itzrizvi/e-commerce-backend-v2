module.exports = {
    ...require('./productConditionQueries'),
    ...require('./productAvailabilityStatusQueries'),
}