This folder is required however is empty.
Photo will upload on this temporary directory after upload aws photo willl be delete so this folder is needed.
So please dont delete the folder.