module.exports = {
    getAllStaffsController: require("./getAllStaffsController"),
    updateAdminController: require("./updateAdminController"),
    getSingleAdminController: require("./getSingleAdminController"),
    adminPasswordChangeController: require("./adminPasswordChangeController"),
}