// 
module.exports = {
    getAddressListByCustomerIDController: require("./getAddressListByCustomerIDController"),
    getAddressListByVendorIDController: require("./getAddressListByVendorIDController"),
    getStateListController: require("./getStateListController"),
    getCountryListController: require("./getCountryListController"),
}